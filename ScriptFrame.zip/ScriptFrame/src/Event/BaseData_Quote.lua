Events = {}
-- Opencv
loadLibrary("opencv")  
-- Data
Events.BDAPI		= require("Event.BaseData_API")
Events.BDViewParam	= require("Event.BaseData_ViewParam")
Events.BDMethod		= require("Event.BaseData_Method")

Events.BDConfig		= require("Event.BaseData_UserConfig")

--Show
Events.BVSLM		= require("View.BaseView_SLM")
Events.BVJSON		= require("View.BaseView_JSON")
Events.BVInitInt	= require("View.BaseView_Init")
Events.BVGUIView	= require("View.BaseView_GUI")

--RUN
Events.THEGUN		= require("Model.PageOne.TheGun")
Events.MapSet       = require("Model.PageOne.MapSet")
Events.GlassTime    = require("Model.PageOne.GlassTime")
-- TODO
return Events
--引用脚本
