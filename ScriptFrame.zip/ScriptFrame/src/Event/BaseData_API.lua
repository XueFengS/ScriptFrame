BaseData_API = {}

-- 获取引擎版本号
BaseData_API.EngineVersion = getEngineVersion()
-- 获取手机系统类型
BaseData_API.OSType = getOSType()
-- 获取宽度与高度
BaseData_API.Width,BaseData_API.Height  = getScreenSize()
-- 获取屏幕方向
BaseData_API.ScreenDirection = getScreenDirection()
-- 获取DPI
BaseData_API.CreenDPI = getScreenDPI()
-- 获取时间戳
BaseData_API.TimeStamp = mTime()
--  创建 HUD 
BaseData_API.FirstHUD = createHUD()
-- 获取用户ID
--BaseData_API.UserID = getUserID()
-- 获取当前的电池状态
BaseData_API.Charge,BaseData_API.Level = getBatteryLevel()

--获取爱游版本信息
function getAppInfoExit()
	local info = getAppInfo("com.whkj.assist")
	BaseData_API.PkgName = info["pkgName"]
	BaseData_API.VersionName = info["versionName"] 
	BaseData_API.DataDir = info["dataDir"]
	BaseData_API.ExtDataDir = info["extDataDir"]
end

return BaseData_API

-->获取手机信息

