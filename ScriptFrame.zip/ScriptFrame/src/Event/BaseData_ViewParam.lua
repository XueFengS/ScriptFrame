DataViews = {}

DataViews.Values    = nil
--  UI界面宽度、高度
DataViews.boxWidth  = 1.2
DataViews.boxHeight = 0.5

-- ui 参数
HC_num = 0
Card_lingqu = nil
Card_chupai = nil
Card_jineng = nil
Card_baoju  = nil
Card_yuzhu  = nil
Card_zhixiang = nil

-- 引擎版本号限制  当前/不低于
DataViews.minVer    = 1018
DataViews.ratio     = ""
DataViews.HUDColor  = "0xfffdff56"
--爱游主版本号限制
DataViews.minVersion = 217
-- 
return DataViews
--> 全局参数
