MethodExmp = {}

-- 单图模糊识别
function MethodExmp:findSingleImage(image,degree,topx,topy,botx,boty,alpha)
	degree= degree or 90
	x, y = findImageInRegionFuzzyExt(image,degree,topx,topy,botx,boty,alpha)
	dialog("x,y")
	if  x ~= -1 and y ~= -1 then
		sysLog("找到图片 ：".. image .. "范围".. topx..","..topy..","..botx..","..boty)
		return true
	else 
		return false
	end
end
-- 复杂图形模糊识别
function MethodExmp:findMoreImage(image,arr,degree,ignore)
	degree= degree or 90
	ret, results = findImage(image,arr,degree,ignore)
	if ret then
		sysLog("识别图片：".. image .. "成功")
		return true
	else 
		sysLog("识别图片：".. image .. "失败")
		return false
	end
end

-- 简单轮廓多图识别
function MethodExmp:findMoreShape(image,arr,degree,ignore)
	degree= degree or 0.1
	ret, results = findShape(image,arr,degree,ignore)
	if ret then
		sysLog("识别图片：".. image .. "成功")
		return true
	else 
		sysLog("识别图片：".. image .. "失败")
		return false
	end
end


function MethodExmp:tap(x,y,sleep)
	sleep = sleep or 20
	val = math.random(-4,4)
	touchDown(1,x + val,y + val)
	mSleep(math.random(84 + val,314 + val))
	touchUp(1,x + val,y + val)
	mSleep(sleep + val)
return MethodExmp.tap
end

--字符串分割移除 返回新字符串
function MethodExmp:split(input, delimiter) 
	local newString = "0"
	input = tostring(input)  
    delimiter = tostring(delimiter)  
    if (delimiter=='') then return false end  
    local pos,arr = 0, {}  
    -- for each divider found
    for st,sp in function() return string.find(input, delimiter, pos, true) end do  
        table.insert(arr, string.sub(input, pos, st - 1))  
        pos = sp + 1  
    end  
    table.insert(arr, string.sub(input, pos))
    if table.getn(arr) > 0 then
    	newString = table.concat(arr)
    end 
    return newString 
end

-- 当前版本函数是否存在判断
function MethodExmp:callInterface(f)
	if pcall(f) then
    sysLog("ok")
		return true
  else
    local ret,errMessage = pcall(f)
    if ret == false then
      sys("errMessage:"..errMessage)
    end
		return false
  end
end

function MethodExmp:mSleep(sl)
	sl =  sl + math.random(1,98)
	mSleep(sl) 
	sysLog("延迟 :" .. sl)
end

function MethodExmp:findExt(arr,sys,sim,long) 
	point = findMultiColorInRegionFuzzyExt(arr[1], arr[2], sim, arr[3], arr[4], arr[5], arr[6])
	sysLog("表长度为".. #point )
	if #point >= long then
		return true 
	end
		return false 
end

function MethodExmp:findColors(arr,sys)
	x,y = findColor({arr[1],arr[2],arr[3],arr[4]},arr[5])
	if x ~= -1 and y ~= -1 then
		sysLog("找到颜色:" .. sys)
		return true
	end 
	return false
end

function MethodExmp:findColorss(x1,y1,x2,y2,col)
	x,y = findColor({x1,y1,x2,y2},col)
	if x ~= -1 and y ~= -1 then
		return true
	end 
	return false
end

function MethodExmp:findColorsTap(arr,sys)
	x,y = findColor({arr[1],arr[2],arr[3],arr[4]},arr[5])
	sysLog("找到？？？？" .. sys..","..x..","..y)
	if x ~= -1 and y ~= -1 then
		MethodExmp:tap(x,y)
		sysLog("找到颜色:" .. sys)
		return true
	end 
	return false
end

function MethodExmp:stap(x,y,initDelay,endDelay)  --tap
	initDelay = initDelay or 20
	endDelay = endDelay or 20 
	mSleep(initDelay)
	MethodExmp:tap(x,y)
	mSleep(endDelay)
 return MethodExmp.stap
end

function MethodExmp:find(arr, sys, sim) --模糊找色
	sysLog('当前进行操作为 ： ' .. sys)
  sim = sim or 90
  arr[7] = arr[7] or 0
  arr[8] = arr[8] or 0
  x, y = findMultiColorInRegionFuzzy(arr[1], arr[2], sim, arr[3], arr[4], arr[5], arr[6], arr[7], arr[8])
  if x > -1 then
    if sys then
      sysLog( sys .. " : ".. "true    " .. x .. "，" .. y)
    end
    return true
  end
    sysLog( sys .. " : ".. "flase    ")
    return false
end

function MethodExmp:findtap(arr, sys, sim,xm,ym) -- 模糊找色点击
	sysLog("findtap 即将点击为:" .. sys)
  xm = xm or 0
  ym = ym or 0
  sim = sim or 90
  arr[7] = arr[7] or 0
  arr[8] = arr[8] or 0
  x, y = findMultiColorInRegionFuzzy(arr[1], arr[2], sim, arr[3], arr[4], arr[5], arr[6], arr[7], arr[8])
	if xm ~= 0 and ym ~= 0 then
		if x > xm then
		 xm = x - xm
		elseif x < xm then
		 xm = xm - x 
		end
		if y > ym then
		 ym = y - ym
		elseif y < ym then
		 ym = ym - y
		end
	end
  if x > -1 then
    if sys then
      sysLog(sys .. "X : ".. x .. "+".. xm .. "，Y: " .. y .."+".. ym )
    end
    MethodExmp:stap(x + xm,y + ym)
    return true
  end
  return false
end

function MethodExmp:slide(start_x,start_y,value,sleep,val,id) -- 滑动
	touchDown(1, start_x, start_y)
	for i = 0, value,val do   
 	   touchMove(1, start_x , start_y+ i)
 	   mSleep(sleep)         
	end
	touchUp(1, start_x , start_y + value)
end

function MethodExmp:moveRA(sx,sy,vala,sle)
	touchDown(1, sx, sy)
	for i = 0, vala,30 do   
 	   touchMove(1, sx + i , sy + i/1.2)
 	   mSleep(30)         
	end
	mSleep(sle)
	touchUp(1, sx + vala , sy + vala/1.2)
end

function MethodExmp:moveRB(sx,sy,vala,sle)
	touchDown(1, sx, sy)
	for i = 0, vala,30 do   
 	   touchMove(1, sx + i , sy - i/1.2)
 	   mSleep(30)         
	end
	mSleep(sle)
	touchUp(1, sx + vala , sy - vala/1.2)
end

function MethodExmp:moveLA(sx,sy,ex,ey,vala,sle)
	touchDown(1, sx, sy)
	for i = 0, vala,30 do   
 	   touchMove(1, ex - i , ey )
 	   mSleep(30)         
	end
	mSleep(sle)
	touchUp(1, ex - vala , ey )
end

function MethodExmp:ColorNumEx(c, x1, y1, x2, y2, sim)
  sim = sim or 90
  local gs, rr, gg, bb = 0, nil, nil, nil
  local fl, abs = math.floor, math.abs
  sim = fl(255 * (100 - sim) * 0.01)
  local r, g, b = fl(c / 65536), fl(c % 65536 / 256), fl(c % 256)
  for i = x1, x2 do
    for j = y1, y2 do
      rr, gg, bb = getColorRGB(i, j)
      if sim >= abs(r - rr) and sim >= abs(g - gg) and sim >= abs(b - bb) then
        gs = gs + 1
      end
    end
  end
  return gs
end

function MethodExmp:ColorNumExt(c, arr, sim)
  sim = sim or 90
  local gs, rr, gg, bb = 0, nil, nil, nil
  local fl, abs = math.floor, math.abs
  sim = fl(255 * (100 - sim) * 0.01)
  local r, g, b = fl(c / 65536), fl(c % 65536 / 256), fl(c % 256)
  for i = arr[1], arr[3] do
    for j = arr[2], arr[4] do
      rr, gg, bb = getColorRGB(i, j)
      if sim >= abs(r - rr) and sim >= abs(g - gg) and sim >= abs(b - bb) then
        gs = gs + 1
        if gs >= 6 then
        	return true
        end
      end
    end
  end
  return false
end

function MethodExmp:rolMove(t_x,t_y,b_x,b_y,sle,id)
	id = id or math.random(1,3)
	touchDown(id,t_x,t_y)
	mSleep(200)
	touchMove(id,b_x,b_y)
	mSleep(sle)
	touchUp(id,b_x,b_y)
	return MethodExmp.rolMove
end

function MethodExmp:jiebing(as_x,as_y,bs_x,bs_y,value,sleep)
	touchDown(1, as_x, as_y)              
	touchDown(2, bs_x, bs_y)            
	mSleep(30) 
	for i = 1, value, 20 do              
	    touchMove(1, as_x - i, as_y - i)  	
	    touchMove(2, bs_x + i, bs_y + i) 
	    mSleep(sleep) 
	end
	touchUp(1, as_x - value, as_y - value)    
	touchUp(2, bs_x + value, bs_y + value) 
    return MethodExmp.jiebing 
end

function MethodExmp:swip(x1, y1, x2, y2,sle)
	sle = sle or 30
	touchDown(1, x1, y1)
	mSleep(sle)
	touchMove(1, x2, y2)
	mSleep(30)
	touchUp(1, x2, y2)
end

function MethodExmp:isColor(x,y,c,s)   --x,y为坐标值，c为颜色值，s为相似度，范围0~100。
  local fl,abs = math.floor,math.abs
  s = fl(0xff*(100-s)*0.01)
  local r,g,b = fl(c/0x10000),fl(c%0x10000/0x100),fl(c%0x100)
  local rr,gg,bb = getColorRGB(x,y)
  if abs(r-rr)<s  and abs(g-gg)<s  and abs(b-bb)<s then
	sysLog("isColor找到点:".. x ..",".. y)
      return true
  end
  return false
end

function  MethodExmp:ColorContrast(s,sle)-- 颜色对比
	color = getColor(width/2,height/2)
	keepScreen(false)	
	mSleep(sle)
	keepScreen(true)
	if MethodExmp:isColor(width/2,height/2,color,s) then
		sysLog(sle .. ": 之前的颜色与" .. sle .. ": 之后的图片匹配")
		return true
	else
		return false
	end
end

return  MethodExmp
--> 主要调用的方法

