UserConfig = {}
function UserConfig:run()
	Events.THEGUN.run()
end		

return UserConfig
--> 用户配置

