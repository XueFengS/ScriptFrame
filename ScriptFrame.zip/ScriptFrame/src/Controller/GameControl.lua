require("Event.BaseData_Quote")
ControllerL = {}

function ControllerL:StartGame()
	-- init
	Events.BVInitInt.engineVersion(Events.BDViewParam.minVer)
	Events.BVInitInt.OSType(Events.BDAPI.OSType)	
	Events.BVInitInt.initScreen(Events.BDAPI.OSType,Events.BDAPI.Width,Events.BDAPI.Height)
	Events.BVInitInt.batteryStatus(Events.BDAPI.Charge,Events.BDAPI.Level)
	Events.BVInitInt.initView()
	Events.BVInitInt.hideView(Events.BDAPI.FirstHUD)
	Events.BVInitInt.VersionNumberLimit()

	-- ui
	-- Events.BDViewParam.Values = Events.BVGUIView.MainUI()

	-- run
	Events.BDConfig.run()
	-- TODO
end

return ControllerL
