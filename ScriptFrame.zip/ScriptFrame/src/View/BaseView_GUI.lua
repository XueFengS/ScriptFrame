MUI = {}
function MUI:MainUI()
	local w_,h_ = Events.BDAPI.Width,Events.BDAPI.Height
	local w = w_
	local h = h_
	local ok = "确定"
	local cancel = "取消"
	local img = "white.jpg"
	Events.BVJSON:new(w,h,ok,cancel,img,"xx.dat")
	local uifactor = 1
	local uifactor1 = 1
	local uifactor2 = 1
	local factor = 1
	local ver = getOSType()
	if h_ == 1440 then
		gdSetTop = -1.3
		paotaiSet = 4
	elseif h_ >= 1280 then
		gdSetTop = -1
		paotaiSet = 4.5
	end
	if ver == "android" then
		uifactor = 1.2
		uifactor1 = 1.2
		uifactor2 = 0.9
	elseif ver == "ios" then
	end
	
-- Page 1
  local p = Events.BVJSON:newPage("主要功能")
	
  p:newLine(0.7)
  local b = p:newBox(1.3, 10)
  local b = p:newBox(8, 10)
  b:addLebel(1.8 * uifactor, 1 * uifactor2, "智能识别武器:", 25, "left", "155,155,155")
  b:addRadioBoxGroup2(4.5 * uifactor, 1 * uifactor2, "智能识别", "0", "开启","关闭")
  b:newLine(0.2)

  b:addLebel(1.8 * uifactor, 1 * uifactor2, "放大镜设置:", 25, "left", "155,155,155")
  b:addRadioBoxGroup2(4.5 * uifactor, 1 * uifactor2, "放大镜设置", "1", "开启","关闭")
  b:newLine(0.2)
  b:addLebel(1.8 * uifactor, 1 * uifactor2, "变声器设置:", 25, "left", "155,155,155")
  b:addRadioBoxGroup2(4.5 * uifactor, 1 * uifactor2, "变声器设置", "1", "开启","关闭")
  b:newLine(0.2)

  local p = Events.BVJSON:newPage("脚本公告")
  local b = p:newBox(1, 10)
  local b = p:newBox(8, 10)
  b:newLine(0.5)
  b:addLebel(8, 0.75, "1 . 压枪须设置开火模式为自动模式.", 25, "left", "155,155,155")
  b:newLine(0.5)
  b:addLebel(8, 0.75, "2 . 请完全进入游戏界面后再开启脚本.", 25, "left", "155,155,155")
  b:newLine(0.5)

	local ret, result = Events.BVJSON:show()
	if ret == 0 then
		lua_exit()
	end
	return result
end
return MUI
