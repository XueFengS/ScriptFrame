Initialize = {}
-- 爱游引擎版本号判断
www, hhh = getScreenSize()
function Initialize:engineVersion(minVer)
	if  self ~= nil and minVer ~= nil then
		if type(self) == "number" and self >= minVer then
			ShowHUDMessage:showHUDs("当前为最新版本",math.random(20,200))
		else
			-- dialog("发现新版本, 是否要更新 ?")
			--lua_exit()
		end

	else
		sysLog("版本信息错误 - error : nil")
	end
	return Initialize.engineVersion	
end
-- 手机系统类型
function Initialize:OSType()
	if self ~= nil then
		if self == "android" then
			init("0",1)
		elseif self == "IOS" then
			init("0",1)
			setUIOrientation(0)
		end
		ShowHUDMessage:showHUDs("方向初始化完毕",math.random(20,200))
	else
		sysLog("方向初始化错误	 - error : ")
	end
	return Initialize.OSType
end
-- 设置屏幕缩放
function  Initialize:initScreen(w,h)	
	if self ~= nil and w ~= nil and h ~= nil then
	local scale = w/h 
		if scale > 0.562 and scale <0.563 then
			Events.BDViewParam.ratio = "Android_16:9"
			if self == "android" then
				setScreenScale(w,h)
			elseif self == "ios" then
			Events.BDViewParam.ratio = "IOS_16:9"
				setScreenScale(h,w)	
			end
		elseif scale == 0.5 then
			Events.BDViewParam.ratio  = "Android_18:9"
			setScreenScale(w,h)
		end	
		ShowHUDMessage:showHUDs("分辨率设置完毕",math.random(20,200))
	else
		sysLog("设置缩放错误")
	end

	return Initialize.initScreen
end
-- 当前电池状态
function Initialize:batteryStatus(Lev)
	local batstaText 
	if self ~= nil and Lev ~= nil then
		if self == 0 and Lev <= 30 then
	 		if self == 0 then
	   	 		 batstaText = "未连接电源" 
		  	else
	  	  		 batstaText = "已连接电源" 
		  	end
		end
		ShowHUDMessage:showHUDs("当前电量 ".. Lev .. "%",math.random(20,200))
	else
		sysLog("电源状态 : error -".. self .."电池电量 : error -".. Lev)
	end

	return Initialize.batteryStatus
end
-- 爱游主版本判号判断
function Initialize:VersionNumberLimit()
  if MethodExmp:callInterface(getAppInfoExit) then
    local currentVersion = tonumber(MethodExmp:split(BaseData_API.VersionName,"."))
	  if currentVersion >= Events.BDViewParam.minVersion then
	  	sysLog("当前版本号:"..currentVersion)
	  else
	  	dialog("\n\n当前爱游版本不支持该脚本,\n\n请更新至最新版本后运行!")
	    lua_exit()
	  end
  else
    dialog("\n\n当前爱游版本不支持该脚本,\n\n请更新至最新版本后运行!")
    lua_exit()
  end
end
function Initialize:initView() 
	ShowHUDMessage:showHUDs("初始化界面.  ",math.random(20,200))
	ShowHUDMessage:showHUDs("初始化界面.. ",math.random(20,200))
	ShowHUDMessage:showHUDs("初始化界面...",math.random(20,200))
	return  Initialize.initView
end
function Initialize:hideView()
	ShowHUDMessage:hideHUDs(Events.BDAPI.FirstHUD) 
	return Initialize.hideView
end
return Initialize
--> 初始化设置

