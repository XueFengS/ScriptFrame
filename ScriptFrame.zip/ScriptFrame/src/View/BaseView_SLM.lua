ShowHUDMessage = {}
function ShowHUDMessage:showHUDs(self,msleep)
	showHUD(Events.BDAPI.FirstHUD,self,36,"0xfffdff56","0x55000000",0,0,0,Events.BDAPI.Height,Events.BDAPI.Width)
	mSleep(msleep)
	return ShowHUDMessage.showHUDs
end

function ShowHUDMessage:hideHUDs(self) 
	hideHUD(self)
	return ShowHUDMessage.hideHUDs
end

--> show脚本加载信息
