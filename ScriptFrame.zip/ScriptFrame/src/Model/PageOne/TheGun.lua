GUN = {}

local RP = 0

AKM		= nil
AUG		= nil
DP_28 	= nil
GROZA 	= nil
M16A4 	= nil
M249 	= nil
M416 	= nil
SCAR_L 	= nil
UMP9 	= nil
Uzi 	= nil
Vector 	= nil
VSS 	= nil
Thomson = nil

currentGunId = 1

arr = {}
pullDownFrequencyArr = {}
pullDownRangeArr = {}
range = {}
range_left = {}
range_leftColor = {}
range_rightColor = {}
range_right = {}
col = 0xffdf00 
function look_A_Gun()
	if RP == 1 then
		range = {474,623,805,677}
		range_leftColor = {467,617,497,679}
		range_rightColor = {639,621,662,678}
		range_left = {475,623,638,678}
		range_right = {643,625,804,675}
		AKM		= "AKM_1.png"
		AUG		= "AUG_1.png"
		DP_28 	= "DP_28_1.png"
		GROZA 	= "GROZA_1.png"
		M16A4 	= "M16A4_1.png"
		M249 	= "M249_1.png"
		M416 	= "M416_1.png"
		SCAR_L 	= "SCAR-L_1.png"
		UMP9 	= "UMP9_1.png"
		Uzi 	= "Uzi_1.png"
		Vector 	= "Vector_1.png"
		VSS 	= "VSS_1.png"
		Thomson = "Thomson_1.png"
	end

	if RP == 2 then
		range = {554,623,884,678}
		range_leftColor = {547,619,569,677}
		range_rightColor = {719,621,739,676}
		range_left = {555,625,717,676}
		range_right = {723,625,884,677}
		AKM		= "AKM_2.png"
		AUG		= "AUG_2.png"
		DP_28 	= "DP_28_2.png"
		GROZA 	= "GROZA_2.png"
		M16A4 	= "M16A4_2.png"
		M249 	= "M249_2.png"
		M416 	= "M416_2.png"
		SCAR_L 	= "SCAR-L_2.png"
		UMP9 	= "UMP9_2.png"
		Uzi 	= "Uzi_2.png"
		Vector 	= "Vector_2.png"
		VSS 	= "VSS_2.png"
		Thomson = "Thomson_2.png"
	end

	if RP == 3 then
		range = {593,956,1023,1027}
		range_leftColor = {467,617,497,679}
		range_rightColor = {639,621,662,678}
		range_left = {595,955,807,1025}
		range_right = {813,958,1022,1025}
		AKM		= "AKM_3.png"
		AUG		= "AUG_3.png"
		DP_28 	= "DP_28_3.png"
		GROZA 	= "GROZA_3.png"
		M16A4 	= "M16A4_3.png"
		M249 	= "M249_3.png"
		M416 	= "M416_3.png"
		SCAR_L 	= "SCAR-L_3.png"
		UMP9 	= "UMP9_3.png"
		Uzi 	= "Uzi_3.png"
		Vector 	= "Vector_3.png"
		VSS 	= "VSS_3.png"
		Thomson = "Thomson_3.png"		
	end

	if RP == 4 then
		range = {711,936,1210,1017}
		range_leftColor = {707,932,734,1018}
		range_rightColor = {958,930,991,1015}	
		range_left = {712,938,953,1012}
		range_right = {963,936,1208,1015}
		AKM		= "AKM_4.png"
		AUG		= "AUG_4.png"
		DP_28 	= "DP_28_4.png"
		GROZA 	= "GROZA_4.png"
		M16A4 	= "M16A4_4.png"
		M249 	= "M249_4.png"
		M416 	= "M416_4.png"
		SCAR_L 	= "SCAR-L_4.png"
		UMP9 	= "UMP9_4.png"
		Uzi 	= "Uzi_4.png"
		Vector 	= "Vector_4.png"
		VSS 	= "VSS_4.png"
		Thomson = "Thomson_4.png"	
	end

	if RP == 5 then
		range = {824,933,1335,1015}
		range_leftColor = {818,931,847,1020}
		range_rightColor = {1083,930,1109,1019}
		range_left = {825,935,1076,1015}
		range_right = {1083,936,1333,1015}
		AKM		= "AKM_5.png"
		AUG		= "AUG_5.png"
		DP_28 	= "DP_28_5.png"
		GROZA 	= "GROZA_5.png"
		M16A4 	= "M16A4_5.png"
		M249 	= "M249_5.png"
		M416 	= "M416_5.png"
		SCAR_L 	= "SCAR-L_5.png"
		UMP9 	= "UMP9_5.png"
		Uzi 	= "Uzi_5.png"
		Vector 	= "Vector_5.png"
		VSS 	= "VSS_5.png"
		Thomson = "Thomson_5.png"
	end

	if RP == 6 then
		range = {884,935,1394,1015}
		range_leftColor = {879,928,904,1018} 	
		range_rightColor = {1139,934,1168,1015}
		range_left = {883,935,1136,1015}
		range_right = {1142,934,1394,1016}
		AKM		= "AKM_6.png"
		AUG		= "AUG_6.png"
		DP_28 	= "DP_28_6.png"
		GROZA 	= "GROZA_6.png"
		M16A4 	= "M16A4_6.png"
		M249 	= "M249_6.png"
		M416 	= "M416_6.png"
		SCAR_L 	= "SCAR-L_6.png"
		UMP9 	= "UMP9_6.png"
		Uzi 	= "Uzi_6.png"
		Vector 	= "Vector_6.png"
		VSS 	= "VSS_6.png"
		Thomson = "Thomson_6.png"		
	end

	if RP == 7 then
		range = {938,1245,1620,1353}
		range_leftColor = {929,1242,969,1357}
		range_rightColor = {1278,1243,1316,1355} 	 	
		range_left = {940,1248,1275,1354}
		range_right = {1285,1246,1617,1352}
		AKM		= "AKM_7.png"
		AUG		= "AUG_7.png"
		DP_28 	= "DP_28_7.png"
		GROZA 	= "GROZA_7.png"
		M16A4 	= "M16A4_7.png"
		M249 	= "M249_7.png"
		M416 	= "M416_7.png"
		SCAR_L 	= "SCAR-L_7.png"
		UMP9 	= "UMP9_7.png"
		Uzi 	= "Uzi_7.png"
		Vector 	= "Vector_7.png"
		VSS 	= "VSS_7.png"
		Thomson = "Thomson_7.png"
	end

	if RP == 8 then
		range = {1139,1248,1811,1353}
		range_leftColor = {1128,1239,1172,1357}
		range_rightColor = {1477,1240,1515,1355}	
		range_left = {1139,1247,1475,1355}
		range_right = {1484,1247,1818,1354}
		AKM		= "AKM_8.png"
		AUG		= "AUG_8.png"
		DP_28 	= "DP_28_8.png"
		GROZA 	= "GROZA_8.png"
		M16A4 	= "M16A4_8.png"
		M249 	= "M249_8.png"
		M416 	= "M416_8.png"
		SCAR_L 	= "SCAR-L_8.png"
		UMP9 	= "UMP9_8.png"
		Uzi 	= "Uzi_8.png"
		Vector 	= "Vector_8.png"
		VSS 	= "VSS_8.png"
		Thomson = "Thomson_8.png"	
	end
	pullDownSet()
end
function pullDownSet()
	if RP == 1 or RP == 2 then
		arr[1] = M416
		pullDownFrequencyArr[1] = 60 --ok
		pullDownRangeArr[1] = 2

		arr[2] = SCAR_L
		pullDownFrequencyArr[2] = 70 -- ok
		pullDownRangeArr[2] = 2

		arr[3] = AKM
		pullDownFrequencyArr[3] = 83 -- ok
		pullDownRangeArr[3] = 3

		arr[4] = UMP9
		pullDownFrequencyArr[4] = 100 --ok
		pullDownRangeArr[4] = 2

		arr[5] = M16A4
		pullDownFrequencyArr[5] = 120 --ok
		pullDownRangeArr[5] = 2

		arr[6] = Uzi
		pullDownFrequencyArr[6] = 140 --ok
		pullDownRangeArr[6] = 2

		arr[7] = VSS
		pullDownFrequencyArr[7] = 131 -- ok
		pullDownRangeArr[7] = 2

		arr[8] = DP_28
		pullDownFrequencyArr[8] = 97 --ok
		pullDownRangeArr[8] = 2

		arr[9] = Vector
		pullDownFrequencyArr[9] = 115 --ok
		pullDownRangeArr[9] = 2

		arr[10] = GROZA
		pullDownFrequencyArr[10] = 70 --ok
		pullDownRangeArr[10] = 2

		arr[11] = AUG
		pullDownFrequencyArr[11] = 84 --ok
		pullDownRangeArr[11] = 2 

		arr[12] = M249
		pullDownFrequencyArr[12] = 110  --ok
		pullDownRangeArr[12] = 2

		arr[13] = Thomson
		pullDownFrequencyArr[13] = 56 --ok
		pullDownRangeArr[13] = 2
	elseif RP == 3 or RP == 4 or RP == 5 or RP == 6 then
		arr[1] = M416
		pullDownFrequencyArr[1] = 60 
		pullDownRangeArr[1] = 2

		arr[2] = SCAR_L
		pullDownFrequencyArr[2] = 60 
		pullDownRangeArr[2] = 2

		arr[3] = AKM
		pullDownFrequencyArr[3] = 66 
		pullDownRangeArr[3] = 3

		arr[4] = UMP9
		pullDownFrequencyArr[4] = 80
		pullDownRangeArr[4] = 2

		arr[5] = M16A4
		pullDownFrequencyArr[5] = 120
		pullDownRangeArr[5] = 2

		arr[6] = Uzi
		pullDownFrequencyArr[6] = 87 
		pullDownRangeArr[6] = 2

		arr[7] = VSS
		pullDownFrequencyArr[7] = 131
		pullDownRangeArr[7] = 2

		arr[8] = DP_28
		pullDownFrequencyArr[8] = 97 
		pullDownRangeArr[8] = 2

		arr[9] = Vector
		pullDownFrequencyArr[9] = 115
		pullDownRangeArr[9] = 2

		arr[10] = GROZA
		pullDownFrequencyArr[10] = 70 
		pullDownRangeArr[10] = 2

		arr[11] = AUG
		pullDownFrequencyArr[11] = 67 
		pullDownRangeArr[11] = 2 

		arr[12] = M249
		pullDownFrequencyArr[12] = 75
		pullDownRangeArr[12] = 2

		arr[13] = Thomson
		pullDownFrequencyArr[13] = 56
		pullDownRangeArr[13] = 2
	elseif RP == 7 or RP == 8 then
		arr[1] = M416
		pullDownFrequencyArr[1] = 60 
		pullDownRangeArr[1] = 2

		arr[2] = SCAR_L
		pullDownFrequencyArr[2] = 60 
		pullDownRangeArr[2] = 2

		arr[3] = AKM
		pullDownFrequencyArr[3] = 66 
		pullDownRangeArr[3] = 3

		arr[4] = UMP9
		pullDownFrequencyArr[4] = 80
		pullDownRangeArr[4] = 2

		arr[5] = M16A4
		pullDownFrequencyArr[5] = 120
		pullDownRangeArr[5] = 2

		arr[6] = Uzi
		pullDownFrequencyArr[6] = 87 
		pullDownRangeArr[6] = 2

		arr[7] = VSS
		pullDownFrequencyArr[7] = 131
		pullDownRangeArr[7] = 2

		arr[8] = DP_28
		pullDownFrequencyArr[8] = 97 
		pullDownRangeArr[8] = 2

		arr[9] = Vector
		pullDownFrequencyArr[9] = 115
		pullDownRangeArr[9] = 2

		arr[10] = GROZA
		pullDownFrequencyArr[10] = 70 
		pullDownRangeArr[10] = 2

		arr[11] = AUG
		pullDownFrequencyArr[11] = 67 
		pullDownRangeArr[11] = 2 

		arr[12] = M249
		pullDownFrequencyArr[12] = 75
		pullDownRangeArr[12] = 2

		arr[13] = Thomson
		pullDownFrequencyArr[13] = 56
		pullDownRangeArr[13] = 2
	else
		arr[1] = M416
		pullDownFrequencyArr[1] = 60 --ok
		pullDownRangeArr[1] = 2

		arr[2] = SCAR_L
		pullDownFrequencyArr[2] = 70 -- ok
		pullDownRangeArr[2] = 2

		arr[3] = AKM
		pullDownFrequencyArr[3] = 83 -- ok
		pullDownRangeArr[3] = 3

		arr[4] = UMP9
		pullDownFrequencyArr[4] = 100 --ok
		pullDownRangeArr[4] = 2

		arr[5] = M16A4
		pullDownFrequencyArr[5] = 120 --ok
		pullDownRangeArr[5] = 2

		arr[6] = Uzi
		pullDownFrequencyArr[6] = 140 --ok
		pullDownRangeArr[6] = 2

		arr[7] = VSS
		pullDownFrequencyArr[7] = 131 -- ok
		pullDownRangeArr[7] = 2

		arr[8] = DP_28
		pullDownFrequencyArr[8] = 97 --ok
		pullDownRangeArr[8] = 2

		arr[9] = Vector
		pullDownFrequencyArr[9] = 115 --ok
		pullDownRangeArr[9] = 2

		arr[10] = GROZA
		pullDownFrequencyArr[10] = 70 --ok
		pullDownRangeArr[10] = 2

		arr[11] = AUG
		pullDownFrequencyArr[11] = 84 --ok
		pullDownRangeArr[11] = 2 

		arr[12] = M249
		pullDownFrequencyArr[12] = 110  --ok
		pullDownRangeArr[12] = 2

		arr[13] = Thomson
		pullDownFrequencyArr[13] = 56 --ok
		pullDownRangeArr[13] = 2
	end
end

function reset()
	ver = getOSType()
	w,h = getScreenSize()

	if w == 720 and h == 1280 then
		RP = 1
	elseif w == 720 and h == 1440 then
		RP = 2
	elseif w == 1080 and h == 1620 then
		RP = 3
	elseif w == 1080 and h == 1920 then
		RP = 4
	elseif w == 1080 and h == 2160 then
    RP = 5
	elseif w == 1080 and h == 2280 then
		RP = 6
	elseif w == 1440 and h == 2560 then
		RP = 7
	elseif w == 1440 and h == 2960 then
		RP = 8
	end
end

function GUN:run()
	reset()
	look_A_Gun()
	sendInitData()

	sysLog("初始化压枪数据")
  	showCustomJavaView(params,user_data)
  	while true do
		spotEvent()
		mapEvent()
		glassEvent()
	end	
	mSleep(999999)
end
function sendInitData()
    params = {}
    params["viewId"] = 888
    params["dexFileName"] = "core.apk"
    params["className"] = "com.m2agic.gameassist.script.dex.ScriptJavaView"
    params["windowWidth"] = -2
    params["windowHeight"] = -2
    params["startX"] = 800 
    params["startY"] = 400
    params["touchable"] = true
    params["focusable"] = false
    params["movable"]=true
    user_data = {}
    user_data["pullDownFrequency"] = 80
    user_data["pullDownRange"] = 2
    user_data["glassTimeState"] = 0
    user_data["mapId"] = 0x7f020016
    user_data["mapState"] = 0
end

-- 枪支识别
function spotEvent()
	sysLog("开始识别","","","",1)
	for i = 1 ,table.maxn(arr) do
		keepScreen(true)
		if MethodExmp:findMoreShape(arr[i],range_left,0.8,'0xd2d2d2 0xffffff') then	 --存在枪支判断,进行初次过滤
			for i = 1 ,table.maxn(arr) do
				if MethodExmp:findMoreImage(arr[i],range_left,80,1) and MethodExmp:ColorNumExt(col,range_leftColor,90) then
					if currentGunId ~= i then
						sysLog("左框武器:".. arr[i])
						currentGunId = i
						user_data["pullDownFrequency"] = pullDownFrequencyArr[currentGunId]
						user_data["pullDownRange"] = pullDownRangeArr[currentGunId]
						sysLog("发送数据")
						sendDataToCustomJavaView(0x777888,user_data)
					end
				end
			end
		elseif MethodExmp:findMoreShape(arr[i],range_right,0.8,'0xd2d2d2 0xffffff') then
			for i = 1 ,table.maxn(arr) do
				if MethodExmp:findMoreImage(arr[i],range_right,80,1) and MethodExmp:ColorNumExt(col,range_rightColor,90) then
					if currentGunId ~= i then
						sysLog("右框武器:".. arr[i])
						currentGunId = i
						user_data["pullDownFrequency"] = pullDownFrequencyArr[currentGunId]
						user_data["pullDownRange"] = pullDownRangeArr[currentGunId]
						sysLog("发送数据")
						sendDataToCustomJavaView(0x777888,user_data)
					end
				end
			end
		else 
			sysLog("Nothing")
		end
		keepScreen(false)
	end
	mSleep(1000)
end
--地图识别
function mapEvent()
	sysLog("地图识别")
	user_data["mapState"] = MapSet.run()
	if user_data["mapState"] == 1 then
		user_data["mapId"] = 0x7f020016
	elseif user_data["mapState"] == 2 then
		user_data["mapId"] = 0x7f02000a
	elseif user_data["mapState"] == 3 then
		user_data["mapId"] = 0x7f020017	
	else 
		user_data["mapId"] = 0
	end
	sysLog("发送数据")
	sendDataToCustomJavaView(0x777886,user_data)
end
function glassEvent()
	sysLog("开镜识别")
	user_data["glassTimeState"] = GlassTime.run()
	sysLog("发送数据")
	sendDataToCustomJavaView(0x777888,user_data)
end
return GUN

