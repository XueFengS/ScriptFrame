GlassTime = {}

function GlassTime:Reset()
	w,h = getScreenSize()
	if w == 720 and h == 1280 then
		开启倍镜 = {
			0xfdf687,"-19|19|0xfeef87,-1|39|0xfbea73,16|19|0xeee67c,12|6|0xfaec87,-15|31|0xf7e771,-14|5|0xf8ea7f,13|31|0xeee279",
			1192, 341, 1264, 416
		}
	end
	
	if w == 720 and h == 1440 then
		开启倍镜 = {
			0xfdf186,
			"-20|20|0xfff37d,-1|39|0xfceb74,17|19|0xfbf286,12|6|0xfbeb87,-14|32|0xeadb72,-14|5|0xf6ed86,14|32|0xf5e97c",
			1356, 339, 1425, 418
		}
	end

	if w == 1080 and h == 1920 then
		开启倍镜 = {
			0xfef087,
			"-30|28|0xfff37f,1|59|0xfbed6f,28|28|0xfff683,20|8|0xfff28b,-22|10|0xfff796,-22|48|0xfcea74,21|49|0xfdf482", 
			1793, 507, 1894, 613
		}
	end

	if w == 1080 and h == 2160 then
		开启倍镜 = {
			0x234a5b,
			"4|6|0x4c4a3e,9|15|0x4b4b3c,13|15|0x3c3c32,19|16|0x5d5646,12|20|0x494c3e,13|26|0xa7985b,8|26|0x1e5b6c",
			510, 59, 587, 142
		}
	end

	if w == 1080 and h == 2280 then
		开启倍镜 = {
			0xfef087,
			"-29|29|0xffef86,-1|58|0xfdee74,27|28|0xfff785,22|10|0xfef285,-20|7|0xfdf489,-22|50|0xfbe776,20|48|0xf5ed7e",
			2030, 502, 2136, 612
		}
	end

	if w == 1440 and h == 2560 then
		开启倍镜 = {
			0xfef286,
			"-39|39|0xfff380,1|79|0xfdf06e,40|39|0xfef480,-29|65|0xfdeb75,-30|13|0xfdf388,30|64|0xfdf080,27|10|0xfef28c",
			2386, 679, 2525, 810
		}
	end	
end

function GlassTime:run()
	GlassTime:Reset()
	while true do
		keepScreen(true)
		if MethodExmp:find(开启倍镜,"开启倍镜",90) then
			return 1
		else
			return 0
		end
		keepScreen(false)
	end
end

return GlassTime