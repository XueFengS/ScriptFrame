-- main方法
StartGames = require("Controller.GameControl")
function  main()
	StartGames.StartGame()
end
main()


